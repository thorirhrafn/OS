# Replace the following reference string with the answer for part P6.1a
export WORST20ALL=1,2,1,2,1,2

# Replace the following reference strings with the answers for part P6.1b
export WORST5FIFO=1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5
export WORST5LRU=1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5
export WORST5MRU=1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5
