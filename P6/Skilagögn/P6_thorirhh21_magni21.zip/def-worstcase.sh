# Replace the following reference string with the answer for part P6.1a
export WORST20ALL=1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20

# Replace the following reference strings with the answers for part P6.1b
export WORST5FIFO=1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5
export WORST5LRU=1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5
export WORST5MRU=1,2,3,4,5,4,5,4,5,4,5,4,5,4,5,4,5,4,5,4
