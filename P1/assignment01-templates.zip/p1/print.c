#include "print.h"

void print_line(int64_t number, char *string)
{
    (void) number;
    (void) string;
    // Add code here.
}
